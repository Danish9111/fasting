import 'package:flutter/material.dart';

class NotificationSettingsPage extends StatefulWidget {
  const NotificationSettingsPage({super.key});

  @override
  State<NotificationSettingsPage> createState() =>
      _NotificationSettingsPageState();
}

class _NotificationSettingsPageState extends State<NotificationSettingsPage> {
  bool fasting = true;
  bool mealReminders = true;
  bool waterIntake = true;
  bool educationalTips = false;
  bool caloriesIntake = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {},
        ),
        title: const Text("Settings", style: TextStyle(color: Colors.black)),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings, color: Colors.black),
            onPressed: () {},
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Notification",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),

            // Card with options
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.1),
                    blurRadius: 6,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Column(
                children: [
                  _buildSwitchTile(
                    icon: Image.asset(
                      "assets/icons/notification.png",
                      width: 20,
                      height: 20,
                    ),
                    label: "Fasting Start/End",
                    value: fasting,
                    onChanged: (val) => setState(() => fasting = val),
                  ),
                  _divider(),
                  _buildSwitchTile(
                    icon: Image.asset(
                      "assets/icons/fork&knif.png",
                      width: 20,
                      height: 20,
                    ),
                    label: "Meal Reminders",
                    value: mealReminders,
                    onChanged: (val) => setState(() => mealReminders = val),
                  ),
                  _divider(),
                  _buildSwitchTile(
                    icon: Image.asset(
                      "assets/icons/waterDrop.png",
                      width: 20,
                      height: 20,
                    ),
                    label: "Water Intake",
                    value: waterIntake,
                    onChanged: (val) => setState(() => waterIntake = val),
                  ),
                  _divider(),
                  _buildSwitchTile(
                    icon: Image.asset(
                      "assets/icons/bulb.png",
                      width: 20,
                      height: 20,
                    ),
                    label: "Educational Tips",
                    value: educationalTips,
                    onChanged: (val) => setState(() => educationalTips = val),
                  ),
                  _divider(),
                  _buildSwitchTile(
                    icon: Image.asset(
                      "assets/icons/fire.png",
                      width: 20,
                      height: 20,
                    ),
                    label: "Calories Intake",
                    value: caloriesIntake,
                    onChanged: (val) => setState(() => caloriesIntake = val),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _divider() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 10),
      child: Divider(height: 1, thickness: 1, color: Colors.grey.shade200),
    );
  }

  Widget _buildSwitchTile({
    required Widget icon,
    required String label,
    required bool value,
    required Function(bool) onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              icon,
              const SizedBox(width: 12),
              Text(label, style: const TextStyle(fontSize: 16)),
            ],
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeThumbColor: Colors.green,
          ),
        ],
      ),
    );
  }
}
