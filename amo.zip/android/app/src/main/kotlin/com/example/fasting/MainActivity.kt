package com.example.fasting

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
